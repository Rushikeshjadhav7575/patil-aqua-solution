# PATIL AQUA SOLUTIONS — GitHub-ready website

## Folder structure
PATIL_AQUA_SOLUTIONS/
├── index.html
├── about.html
├── products.html
├── contact.html
├── css/
│   └── style.css
└── js/
    └── script.js

## Important fixes included
- Contact form ID is consistently `quoteForm`.
- Bottle selector is consistently `bottleType`.
- Product buttons use `data-product`.
- WhatsApp enquiry includes name, phone, business, bottle type, quantity and requirement.
- 10-digit Indian mobile validation.
- Quantity accepts digits only.
- Mobile navigation works.
- Back-to-top button works.
- Current year is automatic.
- All local CSS/JS paths match the GitHub folder structure.
- Added FAQ, business industries, customization section and enquiry workflow.

## Before publishing
1. Keep the exact folder/file names shown above.
2. Upload the whole folder contents to the same GitHub repository.
3. Do not rename `css` or `js`.
4. Test every navigation link.
5. Test every product Request Quote button.
6. Test the contact form on a phone.
7. Replace/add real product photos later if available.
8. Confirm the business phone/email/location details before publishing.
