
document.addEventListener("DOMContentLoaded", () => {
  const preloader = document.getElementById("preloader");
  if (preloader) setTimeout(() => preloader.style.opacity = "0", 250);
  if (preloader) setTimeout(() => preloader.remove(), 700);

  const menuToggle = document.querySelector(".menu-toggle");
  const navbar = document.querySelector(".navbar");
  if (menuToggle && navbar) {
    menuToggle.addEventListener("click", () => {
      navbar.classList.toggle("active");
      menuToggle.classList.toggle("active");
      menuToggle.setAttribute("aria-expanded", navbar.classList.contains("active"));
    });
    navbar.querySelectorAll("a").forEach(a => a.addEventListener("click", () => {
      navbar.classList.remove("active");
      menuToggle.classList.remove("active");
      menuToggle.setAttribute("aria-expanded", "false");
    }));
  }

  const backTop = document.querySelector(".back-to-top");
  window.addEventListener("scroll", () => {
    if (backTop) backTop.classList.toggle("show", window.scrollY > 500);
  });
  if (backTop) backTop.addEventListener("click", () => window.scrollTo({top:0, behavior:"smooth"}));

  document.querySelectorAll(".product-quote").forEach(button => {
    button.addEventListener("click", () => {
      const product = button.dataset.product || "Custom Bottle Requirement";
      const bottleSelect = document.querySelector("#bottleType");
      if (bottleSelect) {
        const match = [...bottleSelect.options].find(o => o.value.toLowerCase() === product.toLowerCase().replace(" custom water bottle","").replace(" custom bottle",""));
        if (match) bottleSelect.value = match.value;
        else if (/250/.test(product)) bottleSelect.value = "250ml";
        else if (/500/.test(product)) bottleSelect.value = "500ml";
        else if (/750/.test(product)) bottleSelect.value = "750ml";
        else if (/1 L/.test(product)) bottleSelect.value = "1 Litre";
        else bottleSelect.value = "Custom";
      }
      const requirement = document.querySelector("#message");
      if (requirement && !requirement.value) requirement.value = `I am interested in ${product}. Please share details, pricing and available options.`;
      const form = document.querySelector("#quoteForm");
      if (form) form.scrollIntoView({behavior:"smooth", block:"start"});
    });
  });

  const phoneInput = document.querySelector("#phone");
  if (phoneInput) phoneInput.addEventListener("input", () => {
    phoneInput.value = phoneInput.value.replace(/\D/g, "").slice(0, 10);
  });

  const quantityInput = document.querySelector("#quantity");
  if (quantityInput) quantityInput.addEventListener("input", () => {
    quantityInput.value = quantityInput.value.replace(/\D/g, "");
  });

  const quoteForm = document.querySelector("#quoteForm");
  if (quoteForm) {
    quoteForm.addEventListener("submit", (e) => {
      e.preventDefault();
      const name = document.querySelector("#name")?.value.trim();
      const business = document.querySelector("#business")?.value.trim();
      const phone = document.querySelector("#phone")?.value.trim();
      const bottleType = document.querySelector("#bottleType")?.value.trim();
      const quantity = document.querySelector("#quantity")?.value.trim();
      const message = document.querySelector("#message")?.value.trim();

      if (!name || !phone) {
        alert("Please enter your name and WhatsApp number.");
        return;
      }
      if (!/^[6-9]\d{9}$/.test(phone)) {
        alert("Please enter a valid 10-digit Indian mobile number.");
        return;
      }

      let text = `Hello PATIL AQUA SOLUTIONS,%0A%0A`;
      text += `Name: ${encodeURIComponent(name)}%0A`;
      text += `WhatsApp: ${encodeURIComponent(phone)}`;
      if (business) text += `%0ABusiness: ${encodeURIComponent(business)}`;
      if (bottleType) text += `%0ABottle Type: ${encodeURIComponent(bottleType)}`;
      if (quantity) text += `%0AEstimated Quantity: ${encodeURIComponent(quantity)}`;
      if (message) text += `%0ARequirement: ${encodeURIComponent(message)}`;

      window.open(`https://wa.me/919404925598?text=${text}`, "_blank");
    });
  }

  document.querySelectorAll("[data-year]").forEach(el => el.textContent = new Date().getFullYear());
});
